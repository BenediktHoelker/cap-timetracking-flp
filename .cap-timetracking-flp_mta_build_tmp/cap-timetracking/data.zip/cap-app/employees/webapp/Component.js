sap.ui.define(["sap/fe/core/AppComponent"], (ac) =>
  ac.extend("cap.timetracking.employees.Component", {
    metadata: { manifest: "json" },
  })
);
