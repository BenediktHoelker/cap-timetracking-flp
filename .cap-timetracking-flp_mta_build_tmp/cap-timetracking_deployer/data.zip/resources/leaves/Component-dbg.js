sap.ui.define(["sap/fe/core/AppComponent"], (ac) =>
  ac.extend("cap.timetracking.leaves.Component", {
    metadata: { manifest: "json" },
  })
);
