sap.ui.define(["sap/fe/core/AppComponent"], (ac) =>
  ac.extend("cap.timetracking.records.Component", {
    metadata: { manifest: "json" },
  })
);
