sap.ui.define(["sap/fe/core/AppComponent"], (ac) =>
  ac.extend("cap.timetracking.customers.Component", {
    metadata: { manifest: "json" },
  })
);
